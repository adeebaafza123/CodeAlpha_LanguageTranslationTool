from tkinter import *
from tkinter import ttk, messagebox
from deep_translator import GoogleTranslator
import pyperclip

# Language Dictionary
languages = {
    "Auto Detect": "auto",
    "English": "en",
    "Urdu": "ur",
    "Hindi": "hi",
    "French": "fr",
    "German": "de"
}

# Translate Function
def translate_text():
    try:
        text = input_text.get("1.0", END).strip()

        source_lang = languages[source_language.get()]
        target_lang = languages[target_language.get()]

        if text == "":
            messagebox.showwarning("Warning", "Please enter text")
            return

        translated = GoogleTranslator(
            source=source_lang,
            target=target_lang
        ).translate(text)

        output_text.delete("1.0", END)
        output_text.insert(END, translated)

    except Exception as e:
        messagebox.showerror("Error", str(e))

# Copy Function
def copy_text():
    translated = output_text.get("1.0", END)
    pyperclip.copy(translated)
    messagebox.showinfo("Copied", "Translated text copied!")

# Main Window
root = Tk()
root.title("Language Translation Tool")
root.geometry("700x500")
root.config(bg="lightblue")

# Heading
Label(
    root,
    text="AI Language Translation Tool",
    font=("Arial", 20, "bold"),
    bg="lightblue"
).pack(pady=10)

# Input Label
Label(
    root,
    text="Enter Text",
    font=("Arial", 12),
    bg="lightblue"
).pack()

# Input Text Box
input_text = Text(root, height=8, width=70)
input_text.pack(pady=10)

# Language Frame
frame = Frame(root, bg="lightblue")
frame.pack()

# Source Language
Label(
    frame,
    text="Source Language",
    bg="lightblue",
    font=("Arial", 11)
).grid(row=0, column=0, padx=20)

source_language = ttk.Combobox(
    frame,
    values=list(languages.keys()),
    width=20
)
source_language.set("Auto Detect")
source_language.grid(row=1, column=0, padx=20)

# Target Language
Label(
    frame,
    text="Target Language",
    bg="lightblue",
    font=("Arial", 11)
).grid(row=0, column=1, padx=20)

target_language = ttk.Combobox(
    frame,
    values=list(languages.keys())[1:],
    width=20
)
target_language.set("Urdu")
target_language.grid(row=1, column=1, padx=20)

# Translate Button
Button(
    root,
    text="Translate",
    font=("Arial", 12, "bold"),
    bg="green",
    fg="white",
    command=translate_text
).pack(pady=15)

# Output Label
Label(
    root,
    text="Translated Text",
    font=("Arial", 12),
    bg="lightblue"
).pack()

# Output Text Box
output_text = Text(root, height=8, width=70)
output_text.pack(pady=10)

# Copy Button
Button(
    root,
    text="Copy Text",
    font=("Arial", 11, "bold"),
    bg="blue",
    fg="white",
    command=copy_text
).pack(pady=10)

root.mainloop()